# Producer - EHDS Logical Information Models v0.4.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Producer**

## ActorDefinition: Producer 

| | |
| :--- | :--- |
| *Official URL*:https://www.xt-ehr.eu/specifications/fhir/actor-producer | *Version*:0.4.0 |
| Active as of 2026-02-25 | *Computable Name*:Producer |



## Resource Content

```json
{
  "resourceType" : "ActorDefinition",
  "id" : "actor-producer",
  "url" : "https://www.xt-ehr.eu/specifications/fhir/actor-producer",
  "version" : "0.4.0",
  "name" : "Producer",
  "status" : "active",
  "date" : "2026-02-25T10:40:44+00:00",
  "publisher" : "Xt-EHR",
  "contact" : [{
    "name" : "Xt-EHR",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.xt-ehr.eu/"
    }]
  }],
  "type" : "system"
}

```
