# Advance directive model - Testing - EHDS Logical Information Models v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Advance directive model**

EHDS Logical Information Models, published by Xt-EHR. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/Xt-EHR/xt-ehr-common/tree/351/merge](https://github.com/Xt-EHR/xt-ehr-common/tree/351/merge) and changes regularly. See the [Directory of published versions](https://www.xt-ehr.eu/specifications/fhir/history.html)

*  [Content](StructureDefinition-EHDSAdvanceDirective.md) 
*  [Detailed Descriptions](StructureDefinition-EHDSAdvanceDirective-definitions.md) 
*  [Mappings](StructureDefinition-EHDSAdvanceDirective-mappings.md) 
*  [XML](StructureDefinition-EHDSAdvanceDirective.profile.xml.md) 
*  [JSON](StructureDefinition-EHDSAdvanceDirective.profile.json.md) 
*  [TTL](StructureDefinition-EHDSAdvanceDirective.profile.ttl.md) 

## Logical Model: EHDSAdvanceDirective - Testing

| |
| :--- |
| Draft as of 2025-10-08 |

### Test Plans

**No test plans are currently available for the Profile.**

### Test Scripts

**No test scripts are currently available for the Profile.**

 IG © 2022+ [Xt-EHR](http://Xt-EHR.eu). Package eu.ehds.models#0.2.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-08 
 

Links:
[Table of Contents](toc.md)|
[QA Report](qa.md)
![](cc0.png)

The Xt-EHR action is co-funded by the European Union, EU4Health Program 2021-2027, under Grant Agreement Nr.º 101128085.

 

