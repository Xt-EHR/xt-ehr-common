# Medical Images - EHDS Logical Information Models v0.2.0

* [**Table of Contents**](toc.md)
* **Medical Images**

EHDS Logical Information Models, published by Xt-EHR. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/Xt-EHR/xt-ehr-common/tree/351/merge](https://github.com/Xt-EHR/xt-ehr-common/tree/351/merge) and changes regularly. See the [Directory of published versions](https://www.xt-ehr.eu/specifications/fhir/history.html)

## Medical Images

* [Information Models](#information-models)
* [FHIR Implementation Guide](#fhir-implementation-guide)
* [IHE Profile](#ihe-profile)
* [Supporting information](#supporting-information)

### Information Models

#### Conceptual view

Imaging result report could be divided into several parts: document header, body and optionally it could also have various attachments.

##### Imaging Result Report

##### Dicom Study Metadata

#### Detail EHDS information models for Imaging

* [Imaging Report Document](StructureDefinition-EHDSImagingReport.md)
* [Imaging Study/Manifest](StructureDefinition-EHDSImagingStudy.md)

### FHIR Implementation Guide

Published version: https://hl7.eu/fhir/imaging-r5/ Work in progress: [Latest build](https://build.fhir.org/ig/hl7-eu/imaging); [GitHub](https://github.com/hl7-eu/imaging/)

### IHE Profile

…

### Supporting information

* [eHealth Network Guideline on Medical Imaging Studies and Reports](https://health.ec.europa.eu/document/download/0079ad26-8f8f-435b-9472-3cd8625f4220_en?filename=ehn_mi_guidelines_en.pdf)

 IG © 2022+ [Xt-EHR](http://Xt-EHR.eu). Package eu.ehds.models#0.2.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-08 
 

Links:
[Table of Contents](toc.md)|
[QA Report](qa.md)
![](cc0.png)

The Xt-EHR action is co-funded by the European Union, EU4Health Program 2021-2027, under Grant Agreement Nr.º 101128085.

 

