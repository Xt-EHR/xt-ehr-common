# Laboratory Report - EHDS Logical Information Models v0.2.0

* [**Table of Contents**](toc.md)
* **Laboratory Report**

EHDS Logical Information Models, published by Xt-EHR. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/Xt-EHR/xt-ehr-common/tree/351/merge](https://github.com/Xt-EHR/xt-ehr-common/tree/351/merge) and changes regularly. See the [Directory of published versions](https://www.xt-ehr.eu/specifications/fhir/history.html)

## Laboratory Report

* [Information Models](#information-models)
* [Detail EHDS information models for Laboratory report](#detail-ehds-information-models-for-laboratory-report)
* [FHIR Implementation Guide](#fhir-implementation-guide)
* [Supporting Information](#supporting-information)

### Information Models

#### Conceptual view

Laboratory result report could be divided into several parts: document header, body and optionally it could also have various attachments.

##### Laboratory Result Report

##### Laboratory Result header

##### Laboratory Result body

##### UML representation

Components of laboratory result report and its representation using UML notation:

### Detail EHDS information models for Laboratory report

* [Laboratory Report Document](StructureDefinition-EHDSLaboratoryReport.md)
* [Laboratory Observation](StructureDefinition-EHDSLaboratoryObservation.md)

### FHIR Implementation Guide

Laboratory Report FHIR Implementation Guide has been published by HL7 Europe ([published version](https://hl7.eu/fhir/laboratory/index.html)). Latest build version can be found [here](https://build.fhir.org/ig/hl7-eu/laboratory/). The changes proposed by Xt-EHR project and approved by the community will be included in the future version of the specification.

MyHealth@EU has adopted HL7 Europe's FHIR IG for laboratory report crossborder service (see [crossborder adaption](https://fhir.ehdsi.eu/laboratory/)).

### Supporting Information

* [eHealth Network Guideline on Laboratory Results](https://health.ec.europa.eu/publications/ehn-laboratory-result-guidelines_en)
* [MyHealth@EU crossborder HL7 FHIR specification](https://fhir.ehdsi.eu/laboratory/)

 IG © 2022+ [Xt-EHR](http://Xt-EHR.eu). Package eu.ehds.models#0.2.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-08 
 

Links:
[Table of Contents](toc.md)|
[QA Report](qa.md)
![](cc0.png)

The Xt-EHR action is co-funded by the European Union, EU4Health Program 2021-2027, under Grant Agreement Nr.º 101128085.

 

