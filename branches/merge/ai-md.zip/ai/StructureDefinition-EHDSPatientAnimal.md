# Patient Animal model - EHDS Logical Information Models v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Patient Animal model**

EHDS Logical Information Models, published by Xt-EHR. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/Xt-EHR/xt-ehr-common/tree/351/merge](https://github.com/Xt-EHR/xt-ehr-common/tree/351/merge) and changes regularly. See the [Directory of published versions](https://www.xt-ehr.eu/specifications/fhir/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-EHDSPatientAnimal-definitions.md) 
*  [Mappings](StructureDefinition-EHDSPatientAnimal-mappings.md) 
*  [XML](StructureDefinition-EHDSPatientAnimal.profile.xml.md) 
*  [JSON](StructureDefinition-EHDSPatientAnimal.profile.json.md) 
*  [TTL](StructureDefinition-EHDSPatientAnimal.profile.ttl.md) 

## Logical Model: Patient Animal model 

| | |
| :--- | :--- |
| *Official URL*:https://www.xt-ehr.eu/specifications/fhir/StructureDefinition/EHDSPatientAnimal | *Version*:0.2.0 |
| Draft as of 2025-10-08 | *Computable Name*:EHDSPatientAnimal |

 
EHDS refined base model for Patient:Animal 

**Usages:**

* Use this Logical Model: [Observation model](StructureDefinition-EHDSObservation.md) and [Specimen model](StructureDefinition-EHDSSpecimen.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/eu.ehds.models|current/StructureDefinition/EHDSPatientAnimal)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

This structure is derived from [Base](http://hl7.org/fhir/R5/types.html#Base) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

This structure is derived from [Base](http://hl7.org/fhir/R5/types.html#Base) 

**Summary**

Mandatory: 0 element(2 nested mandatory elements)

 **Key Elements View** 

#### Terminology Bindings

 **Differential View** 

This structure is derived from [Base](http://hl7.org/fhir/R5/types.html#Base) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

This structure is derived from [Base](http://hl7.org/fhir/R5/types.html#Base) 

**Summary**

Mandatory: 0 element(2 nested mandatory elements)

 

Other representations of profile: [CSV](StructureDefinition-EHDSPatientAnimal.csv), [Excel](StructureDefinition-EHDSPatientAnimal.xlsx) 

 IG © 2022+ [Xt-EHR](http://Xt-EHR.eu). Package eu.ehds.models#0.2.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-08 
 

Links:
[Table of Contents](toc.md)|
[QA Report](qa.md)
![](cc0.png)

The Xt-EHR action is co-funded by the European Union, EU4Health Program 2021-2027, under Grant Agreement Nr.º 101128085.

 

