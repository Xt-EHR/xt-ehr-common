# Organisation model - EHDS Logical Information Models v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Organisation model**

EHDS Logical Information Models, published by Xt-EHR. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/Xt-EHR/xt-ehr-common/tree/351/merge](https://github.com/Xt-EHR/xt-ehr-common/tree/351/merge) and changes regularly. See the [Directory of published versions](https://www.xt-ehr.eu/specifications/fhir/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-EHDSOrganisation-definitions.md) 
*  [Mappings](StructureDefinition-EHDSOrganisation-mappings.md) 
*  [XML](StructureDefinition-EHDSOrganisation.profile.xml.md) 
*  [JSON](StructureDefinition-EHDSOrganisation.profile.json.md) 
*  [TTL](StructureDefinition-EHDSOrganisation.profile.ttl.md) 

## Logical Model: Organisation model 

| | |
| :--- | :--- |
| *Official URL*:https://www.xt-ehr.eu/specifications/fhir/StructureDefinition/EHDSOrganisation | *Version*:0.2.0 |
| Draft as of 2025-10-08 | *Computable Name*:EHDSOrganisation |

 
EHDS refined base model for Health provider or any other type of organisation 

**Usages:**

* Use this Logical Model: [Advance directive model](StructureDefinition-EHDSAdvanceDirective.md), [Coverage model](StructureDefinition-EHDSCoverage.md), [DataSet model](StructureDefinition-EHDSDataSet.md), [Discharge Report model](StructureDefinition-EHDSDischargeReport.md)...Show 10 more,[Document model](StructureDefinition-EHDSDocument.md),[Encounter model](StructureDefinition-EHDSEncounter.md),[Endpoint model](StructureDefinition-EHDSEndpoint.md),[Health professional model](StructureDefinition-EHDSHealthProfessional.md),[Imaging report model](StructureDefinition-EHDSImagingReport.md),[Imaging study model](StructureDefinition-EHDSImagingStudy.md),[Immunisation model](StructureDefinition-EHDSImmunisation.md),[Laboratory report model](StructureDefinition-EHDSLaboratoryReport.md),[Media model](StructureDefinition-EHDSMedia.md)and[Observation model](StructureDefinition-EHDSObservation.md)
* Refer to this Logical Model: [Location model](StructureDefinition-EHDSLocation.md) and [Organisation model](StructureDefinition-EHDSOrganisation.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/eu.ehds.models|current/StructureDefinition/EHDSOrganisation)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

This structure is derived from [Base](http://hl7.org/fhir/R5/types.html#Base) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

This structure is derived from [Base](http://hl7.org/fhir/R5/types.html#Base) 

**Summary**

**Structures**

This structure refers to these other structures:

* [Organisation model(https://www.xt-ehr.eu/specifications/fhir/StructureDefinition/EHDSOrganisation)](StructureDefinition-EHDSOrganisation.md)

 **Key Elements View** 

#### Terminology Bindings

 **Differential View** 

This structure is derived from [Base](http://hl7.org/fhir/R5/types.html#Base) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

This structure is derived from [Base](http://hl7.org/fhir/R5/types.html#Base) 

**Summary**

**Structures**

This structure refers to these other structures:

* [Organisation model(https://www.xt-ehr.eu/specifications/fhir/StructureDefinition/EHDSOrganisation)](StructureDefinition-EHDSOrganisation.md)

 

Other representations of profile: [CSV](StructureDefinition-EHDSOrganisation.csv), [Excel](StructureDefinition-EHDSOrganisation.xlsx) 

 IG © 2022+ [Xt-EHR](http://Xt-EHR.eu). Package eu.ehds.models#0.2.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-08 
 

Links:
[Table of Contents](toc.md)|
[QA Report](qa.md)
![](cc0.png)

The Xt-EHR action is co-funded by the European Union, EU4Health Program 2021-2027, under Grant Agreement Nr.º 101128085.

 

