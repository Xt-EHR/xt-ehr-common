# Consumer - EHDS Logical Information Models v1.0.0

## ActorDefinition: Consumer 



## Resource Content

```json
{
  "resourceType" : "ActorDefinition",
  "id" : "actor-consumer",
  "language" : "en",
  "url" : "https://www.xt-ehr.eu/specifications/fhir/actor-consumer",
  "version" : "1.0.0",
  "name" : "Consumer",
  "status" : "active",
  "date" : "2026-04-02T12:48:10+00:00",
  "publisher" : "Xt-EHR",
  "contact" : [{
    "name" : "Xt-EHR",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.xt-ehr.eu/"
    }]
  }],
  "type" : "system"
}

```
