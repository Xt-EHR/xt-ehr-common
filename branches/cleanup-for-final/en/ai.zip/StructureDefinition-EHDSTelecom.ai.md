# Telecom model - EHDS Logical Information Models v1.0.0

## Logical Model: Telecom model 

 
Model for communication contact information. 

**Usages:**

* Use this Logical Model: [Health professional model](StructureDefinition-EHDSHealthProfessional.md), [Organisation model](StructureDefinition-EHDSOrganisation.md), [Patient model](StructureDefinition-EHDSPatient.md) and [Related person model](StructureDefinition-EHDSRelatedPerson.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/xtehr.eu.ehds.models|current/StructureDefinition/EHDSTelecom)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-EHDSTelecom.csv), [Excel](../StructureDefinition-EHDSTelecom.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "EHDSTelecom",
  "language" : "en",
  "url" : "http://www.xt-ehr.eu/fhir/models/StructureDefinition/EHDSTelecom",
  "version" : "1.0.0",
  "name" : "EHDSTelecom",
  "title" : "Telecom model",
  "status" : "active",
  "date" : "2026-03-29T17:52:51+00:00",
  "publisher" : "Xt-EHR",
  "contact" : [{
    "name" : "Xt-EHR",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.xt-ehr.eu/"
    }]
  }],
  "description" : "Model for communication contact information.",
  "fhirVersion" : "5.0.0",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "logical",
  "abstract" : false,
  "type" : "http://www.xt-ehr.eu/fhir/models/StructureDefinition/EHDSTelecom",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "EHDSTelecom",
      "path" : "EHDSTelecom",
      "short" : "Telecom model",
      "definition" : "Model for communication contact information."
    },
    {
      "id" : "EHDSTelecom.use",
      "path" : "EHDSTelecom.use",
      "short" : "Purpose of the address (eg. home, work)",
      "definition" : "Purpose of the address (eg. home, work)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "EHDSTelecom.type",
      "path" : "EHDSTelecom.type",
      "short" : "Type of communication form (eg. phone, fax, email).",
      "definition" : "Type of communication form (eg. phone, fax, email).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "EHDSTelecom.value",
      "path" : "EHDSTelecom.value",
      "short" : "The actual contact point details (i.e. phone number or email address).",
      "definition" : "The actual contact point details (i.e. phone number or email address).",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
