# Table of Contents - EHDS Logical Information Models v0.2.0

* **Table of Contents**

EHDS Logical Information Models, published by Xt-EHR. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/Xt-EHR/xt-ehr-common/tree/ps-diagram](https://github.com/Xt-EHR/xt-ehr-common/tree/ps-diagram) and changes regularly. See the [Directory of published versions](https://www.xt-ehr.eu/specifications/fhir/history.html)

## Table of Contents

| |
| :--- |
| [0 Table of Contents](toc.md) |
| [1 Home](index.md) |
| [2 How to read this guide](howto.md) |
| [3 Known issues](knownIssues.md) |
| [4 Scope and Content](scope.md) |
| [5 Ways of working](wow.md) |
| [6 ePrescription & eDispensation](useCasePrescription.md) |
| [7 Patient Summary](useCasePatientSummary.md) |
| [8 Laboratory Report](useCaseLabReport.md) |
| [9 Obligations for Laboratory Report](obligationsLabReport.md) |
| [10 Medical Images](useCaseMedicalImages.md) |
| [11 Discharge Report](useCaseHospitalDischargeReport.md) |
| [12 Download](downloads.md) |
| [13 Artifacts Summary](artifacts.md) |
| [13.1 Patient summary model](StructureDefinition-EHDSPatientSummary.md) |
| [13.2 Medication dispense decline model](StructureDefinition-EHDSDispenseDecline.md) |
| [13.3 Medication dispense model](StructureDefinition-EHDSMedicationDispense.md) |
| [13.4 Medication prescription model](StructureDefinition-EHDSMedicationPrescription.md) |
| [13.5 Laboratory observation model](StructureDefinition-EHDSLaboratoryObservation.md) |
| [13.6 Laboratory report model](StructureDefinition-EHDSLaboratoryReport.md) |
| [13.7 Imaging report model](StructureDefinition-EHDSImagingReport.md) |
| [13.8 Imaging study model](StructureDefinition-EHDSImagingStudy.md) |
| [13.9 Discharge Report model](StructureDefinition-EHDSDischargeReport.md) |
| [13.10 Address model](StructureDefinition-EHDSAddress.md) |
| [13.11 Advance directive model](StructureDefinition-EHDSAdvanceDirective.md) |
| [13.12 Alert model](StructureDefinition-EHDSAlert.md) |
| [13.13 Allergy intolerance model](StructureDefinition-EHDSAllergyIntolerance.md) |
| [13.14 Attachment model](StructureDefinition-EHDSAttachment.md) |
| [13.15 Body structure model](StructureDefinition-EHDSBodyStructure.md) |
| [13.16 Care plan model](StructureDefinition-EHDSCarePlan.md) |
| [13.17 Condition model](StructureDefinition-EHDSCondition.md) |
| [13.18 Coverage model](StructureDefinition-EHDSCoverage.md) |
| [13.19 Current pregnancy status model](StructureDefinition-EHDSCurrentPregnancy.md) |
| [13.20 DataSet model](StructureDefinition-EHDSDataSet.md) |
| [13.21 Device model](StructureDefinition-EHDSDevice.md) |
| [13.22 Device use model](StructureDefinition-EHDSDeviceUse.md) |
| [13.23 Document model](StructureDefinition-EHDSDocument.md) |
| [13.24 Dosage model](StructureDefinition-EHDSDosage.md) |
| [13.25 Dosaging model](StructureDefinition-EHDSDosaging.md) |
| [13.26 Encounter model](StructureDefinition-EHDSEncounter.md) |
| [13.27 Endpoint model](StructureDefinition-EHDSEndpoint.md) |
| [13.28 Episode of care model](StructureDefinition-EHDSEpisodeOfCare.md) |
| [13.29 Family member history model](StructureDefinition-EHDSFamilyMemberHistory.md) |
| [13.30 Functional status](StructureDefinition-EHDSFunctionalStatus.md) |
| [13.31 Health professional model](StructureDefinition-EHDSHealthProfessional.md) |
| [13.32 Human name model](StructureDefinition-EHDSHumanName.md) |
| [13.33 Immunisation model](StructureDefinition-EHDSImmunisation.md) |
| [13.34 Infectious contact model](StructureDefinition-EHDSInfectiousContact.md) |
| [13.35 Location model](StructureDefinition-EHDSLocation.md) |
| [13.36 Media model](StructureDefinition-EHDSMedia.md) |
| [13.37 Medication administration model](StructureDefinition-EHDSMedicationAdministration.md) |
| [13.38 Medication model](StructureDefinition-EHDSMedication.md) |
| [13.39 Medication statement model](StructureDefinition-EHDSMedicationStatement.md) |
| [13.40 Observation model](StructureDefinition-EHDSObservation.md) |
| [13.41 Organisation model](StructureDefinition-EHDSOrganisation.md) |
| [13.42 Patient Animal model](StructureDefinition-EHDSPatientAnimal.md) |
| [13.43 Patient model](StructureDefinition-EHDSPatient.md) |
| [13.44 Pregnancy history model](StructureDefinition-EHDSPregnancyHistory.md) |
| [13.45 Procedure model](StructureDefinition-EHDSProcedure.md) |
| [13.46 Related person model](StructureDefinition-EHDSRelatedPerson.md) |
| [13.47 Service request model](StructureDefinition-EHDSServiceRequest.md) |
| [13.48 Social history model](StructureDefinition-EHDSSocialHistory.md) |
| [13.49 Specimen model](StructureDefinition-EHDSSpecimen.md) |
| [13.50 Substance model](StructureDefinition-EHDSSubstance.md) |
| [13.51 Substance use model](StructureDefinition-EHDSSubstanceUse.md) |
| [13.52 Telecom model](StructureDefinition-EHDSTelecom.md) |
| [13.53 Travel history model](StructureDefinition-EHDSTravelHistory.md) |

 IG © 2022+ [Xt-EHR](http://Xt-EHR.eu). Package eu.ehds.models#0.2.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-08 
 

Links:
[Table of Contents](toc.md)|
[QA Report](qa.md)
![](cc0.png)

The Xt-EHR action is co-funded by the European Union, EU4Health Program 2021-2027, under Grant Agreement Nr.º 101128085.

 

