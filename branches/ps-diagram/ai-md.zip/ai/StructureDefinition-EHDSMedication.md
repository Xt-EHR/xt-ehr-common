# Medication model - EHDS Logical Information Models v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Medication model**

EHDS Logical Information Models, published by Xt-EHR. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/Xt-EHR/xt-ehr-common/tree/ps-diagram](https://github.com/Xt-EHR/xt-ehr-common/tree/ps-diagram) and changes regularly. See the [Directory of published versions](https://www.xt-ehr.eu/specifications/fhir/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-EHDSMedication-definitions.md) 
*  [Mappings](StructureDefinition-EHDSMedication-mappings.md) 
*  [XML](StructureDefinition-EHDSMedication.profile.xml.md) 
*  [JSON](StructureDefinition-EHDSMedication.profile.json.md) 
*  [TTL](StructureDefinition-EHDSMedication.profile.ttl.md) 

## Logical Model: Medication model 

| | |
| :--- | :--- |
| *Official URL*:https://www.xt-ehr.eu/specifications/fhir/StructureDefinition/EHDSMedication | *Version*:0.2.0 |
| Active as of 2025-10-08 | *Computable Name*:EHDSMedication |

 
Logical model for prescribed/dispensed medication. The model is shared by statements, requests, dispensations, and treatment lines. Each of those may have different restrictions in FHIR profile. Model is suitable for generic/virtual medications as well as branded/real products. 

**Usages:**

* Use this Logical Model: [Immunisation model](StructureDefinition-EHDSImmunisation.md), [Medication administration model](StructureDefinition-EHDSMedicationAdministration.md), [Medication dispense model](StructureDefinition-EHDSMedicationDispense.md), [Medication prescription model](StructureDefinition-EHDSMedicationPrescription.md)...Show 2 more,[Medication statement model](StructureDefinition-EHDSMedicationStatement.md)and[Service request model](StructureDefinition-EHDSServiceRequest.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/eu.ehds.models|current/StructureDefinition/EHDSMedication)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

This structure is derived from [Base](http://hl7.org/fhir/R5/types.html#Base) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

This structure is derived from [Base](http://hl7.org/fhir/R5/types.html#Base) 

**Summary**

Mandatory: 0 element(6 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [Device model(https://www.xt-ehr.eu/specifications/fhir/StructureDefinition/EHDSDevice)](StructureDefinition-EHDSDevice.md)

 **Key Elements View** 

#### Terminology Bindings

 **Differential View** 

This structure is derived from [Base](http://hl7.org/fhir/R5/types.html#Base) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

This structure is derived from [Base](http://hl7.org/fhir/R5/types.html#Base) 

**Summary**

Mandatory: 0 element(6 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [Device model(https://www.xt-ehr.eu/specifications/fhir/StructureDefinition/EHDSDevice)](StructureDefinition-EHDSDevice.md)

 

Other representations of profile: [CSV](StructureDefinition-EHDSMedication.csv), [Excel](StructureDefinition-EHDSMedication.xlsx) 

 IG © 2022+ [Xt-EHR](http://Xt-EHR.eu). Package eu.ehds.models#0.2.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-08 
 

Links:
[Table of Contents](toc.md)|
[QA Report](qa.md)
![](cc0.png)

The Xt-EHR action is co-funded by the European Union, EU4Health Program 2021-2027, under Grant Agreement Nr.º 101128085.

 

