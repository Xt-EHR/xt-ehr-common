# Scope and Content - EHDS Logical Information Models v0.2.0

* [**Table of Contents**](toc.md)
* **Scope and Content**

EHDS Logical Information Models, published by Xt-EHR. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/Xt-EHR/xt-ehr-common/tree/ps-diagram](https://github.com/Xt-EHR/xt-ehr-common/tree/ps-diagram) and changes regularly. See the [Directory of published versions](https://www.xt-ehr.eu/specifications/fhir/history.html)

## Scope and Content

* [Scope](#scope)
* [Content](#content)
* [Target audience](#target-audience)

### Scope

The Xt-EHR Logical Information Models guide includes computable data models developed for implementing EHDS priority categories:

* ePrescription and eDispensation
* Patient Summary
* Medical Images and Reports
* Laboratory Results and Reports
* Discharge Reports

All models are developed from eHealth Network guidelines and X-eHealth project and refined to be machine-processable and consistenth with eacother.

### Content

The focus of the guides is logical models in various representations (see [How to read this guide](howto.md)). While the implementation guide uses HL7 FHIR tooling for publishing, the models themselves are technology-agnostic and they are not coupled with HL7 FHIR resources for data exchange. These models can be used for designing services or self-assessing the conformity to future EHDS requirements and recommendations.

In addition to models, links to related HL7 FHIR specifications are provided. Referenced HL7 Europe FHIR implementation guides are based on Xt-EHR logical models, and the mapping to logical model elements is provided in the FHIR implementation guides. All EHDS-related FHIR implementation guides are work in progress - the status of the work varies and temporary discrepancies with models may appear.

### Target audience

The models are designed for a wider audience than HL7 FHIR implementation guides for data exchange. Within this guide, multiple presentations (including simplified mindmap-like diagrams) are provided to target different readers and their needs.

The logical information models are useful for:

* Clinicians who are assessing the content or helping EHR vendors to design new services;
* Analysts to understand the requirements and possibilities of implementing EHDS use cases;
* Software designers to design new services and assess the conformance of the existing services;
* Developers for creating or following mappings between different formats.

 IG © 2022+ [Xt-EHR](http://Xt-EHR.eu). Package eu.ehds.models#0.2.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-08 
 

Links:
[Table of Contents](toc.md)|
[QA Report](qa.md)
![](cc0.png)

The Xt-EHR action is co-funded by the European Union, EU4Health Program 2021-2027, under Grant Agreement Nr.º 101128085.

 

