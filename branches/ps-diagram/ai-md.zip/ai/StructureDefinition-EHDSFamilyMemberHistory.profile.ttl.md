# Family member history model - TTL Representation - EHDS Logical Information Models v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Family member history model**

EHDS Logical Information Models, published by Xt-EHR. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/Xt-EHR/xt-ehr-common/tree/ps-diagram](https://github.com/Xt-EHR/xt-ehr-common/tree/ps-diagram) and changes regularly. See the [Directory of published versions](https://www.xt-ehr.eu/specifications/fhir/history.html)

*  [Content](StructureDefinition-EHDSFamilyMemberHistory.md) 
*  [Detailed Descriptions](StructureDefinition-EHDSFamilyMemberHistory-definitions.md) 
*  [Mappings](StructureDefinition-EHDSFamilyMemberHistory-mappings.md) 
*  [XML](StructureDefinition-EHDSFamilyMemberHistory.profile.xml.md) 
*  [JSON](StructureDefinition-EHDSFamilyMemberHistory.profile.json.md) 
*  [TTL](#) 

## Logical Model: EHDSFamilyMemberHistory - TTL Profile

| |
| :--- |
| Draft as of 2025-10-08 |

TTL representation of the EHDSFamilyMemberHistory logical model.

[Raw ttl](StructureDefinition-EHDSFamilyMemberHistory.ttl) | [Download](StructureDefinition-EHDSFamilyMemberHistory.ttl)

 IG © 2022+ [Xt-EHR](http://Xt-EHR.eu). Package eu.ehds.models#0.2.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-08 
 

Links:
[Table of Contents](toc.md)|
[QA Report](qa.md)
![](cc0.png)

The Xt-EHR action is co-funded by the European Union, EU4Health Program 2021-2027, under Grant Agreement Nr.º 101128085.

 

