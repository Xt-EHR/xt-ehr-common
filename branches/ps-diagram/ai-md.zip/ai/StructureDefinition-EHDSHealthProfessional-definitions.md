# Health professional model - Definitions - EHDS Logical Information Models v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Health professional model**

EHDS Logical Information Models, published by Xt-EHR. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/Xt-EHR/xt-ehr-common/tree/ps-diagram](https://github.com/Xt-EHR/xt-ehr-common/tree/ps-diagram) and changes regularly. See the [Directory of published versions](https://www.xt-ehr.eu/specifications/fhir/history.html)

*  [Content](StructureDefinition-EHDSHealthProfessional.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-EHDSHealthProfessional-mappings.md) 
*  [XML](StructureDefinition-EHDSHealthProfessional.profile.xml.md) 
*  [JSON](StructureDefinition-EHDSHealthProfessional.profile.json.md) 
*  [TTL](StructureDefinition-EHDSHealthProfessional.profile.ttl.md) 

## Logical Model: EHDSHealthProfessional - Detailed Descriptions

| |
| :--- |
| Draft as of 2025-10-08 |

Definitions for the EHDSHealthProfessional logical model.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2022+ [Xt-EHR](http://Xt-EHR.eu). Package eu.ehds.models#0.2.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-08 
 

Links:
[Table of Contents](toc.md)|
[QA Report](qa.md)
![](cc0.png)

The Xt-EHR action is co-funded by the European Union, EU4Health Program 2021-2027, under Grant Agreement Nr.º 101128085.

 

