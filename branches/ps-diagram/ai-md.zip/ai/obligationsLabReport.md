# Obligations for Laboratory Report - EHDS Logical Information Models v0.2.0

* [**Table of Contents**](toc.md)
* **Obligations for Laboratory Report**

EHDS Logical Information Models, published by Xt-EHR. This guide is not an authorized publication; it is the continuous build for version 0.2.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/Xt-EHR/xt-ehr-common/tree/ps-diagram](https://github.com/Xt-EHR/xt-ehr-common/tree/ps-diagram) and changes regularly. See the [Directory of published versions](https://www.xt-ehr.eu/specifications/fhir/history.html)

## Obligations for Laboratory Report

* [Overview](#overview)
* [Actors and use cases](#actors-and-use-cases)

### Overview

Obligations are a mean offered by HL7 FHIR to specify functional capabilities that defined actors MAY, SHOULD or SHALL to the data elements specified by the profiles.

This page describes the actors and functional use cases that have been defined for specifying the obligations.

### Actors and use cases

Three actors have been specified:   

* Result report creator
* Result report repository
* Result report consumer

The first is the actor creating the report. This report can be send to a consumer or to a repository for report storage and sharing. The second actor is the system maintaining a copy of the report received, to store and make it available for the consumers. The last actor is the system using the report received or retrieved.


 IG © 2022+ [Xt-EHR](http://Xt-EHR.eu). Package eu.ehds.models#0.2.0 based on [FHIR 5.0.0](http://hl7.org/fhir/R5/). Generated 2025-10-08 
 

Links:
[Table of Contents](toc.md)|
[QA Report](qa.md)
![](cc0.png)

The Xt-EHR action is co-funded by the European Union, EU4Health Program 2021-2027, under Grant Agreement Nr.º 101128085.

 

