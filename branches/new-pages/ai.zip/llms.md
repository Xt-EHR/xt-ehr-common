# xtehr.eu.ehds.models#0.4.0: EHDS Logical Information Models

## Pages

* [Home](index.md)
* [Scope and Content](scope.md)
* [Obligations Framework](obligations.md)
* [Patient Summary](overview-patientsummary.md)
* [ePrescription](overview-prescription.md)
* [Ways of working](wow.md)
* [Obligations for Laboratory Report](obligationsLabReport.md)
* [eDispensation](overview-dispensation.md)
* [How to read this guide](howto.md)
* [Known issues](knownIssues.md)
* [Data types and references](datatypes.md)
* [Artifacts Summary](artifacts.md)
* [Discharge Report](overview-dischargereport.md)
* [Download](downloads.md)
* [Background](background.md)
* [Authoring rules](authoring-process.md)
* [Medical Test Results and Laboratory Report](overview-medicaltestresult.md)
* [Medical Images](overview-medicalimages.md)
* [Change Log](changes.md)

## Resources

### Logicals

* [Address model](StructureDefinition-EHDSAddress.md)
* [Administered dosage model](StructureDefinition-EHDSAdministeredDosage.md)
* [Advance directive model](StructureDefinition-EHDSAdvanceDirective.md)
* [Alert model](StructureDefinition-EHDSAlert.md)
* [Allergy intolerance model](StructureDefinition-EHDSAllergyIntolerance.md)
* [Attachment model](StructureDefinition-EHDSAttachment.md)
* [Body structure model](StructureDefinition-EHDSBodyStructure.md)
* [Care plan model](StructureDefinition-EHDSCarePlan.md)
* [Condition model](StructureDefinition-EHDSCondition.md)
* [Current pregnancy status model](StructureDefinition-EHDSCurrentPregnancy.md)
* [DataSet model](StructureDefinition-EHDSDataSet.md)
* [Device model](StructureDefinition-EHDSDevice.md)
* [Device use model](StructureDefinition-EHDSDeviceUse.md)
* [Discharge Report model](StructureDefinition-EHDSDischargeReport.md)
* [Document model](StructureDefinition-EHDSDocument.md)
* [Dosage model](StructureDefinition-EHDSDosage.md)
* [Encounter model](StructureDefinition-EHDSEncounter.md)
* [Endpoint model](StructureDefinition-EHDSEndpoint.md)
* [Health professional model](StructureDefinition-EHDSHealthProfessional.md)
* [Human name model](StructureDefinition-EHDSHumanName.md)
* [Imaging report model](StructureDefinition-EHDSImagingReport.md)
* [Imaging study model](StructureDefinition-EHDSImagingStudy.md)
* [Immunisation model](StructureDefinition-EHDSImmunisation.md)
* [Laboratory observation model](StructureDefinition-EHDSLaboratoryObservation.md)
* [Laboratory report model](StructureDefinition-EHDSLaboratoryReport.md)
* [Location model](StructureDefinition-EHDSLocation.md)
* [Medication model](StructureDefinition-EHDSMedication.md)
* [Medication administration model](StructureDefinition-EHDSMedicationAdministration.md)
* [Medication dispense model](StructureDefinition-EHDSMedicationDispense.md)
* [Medication dispense model obligations](StructureDefinition-EHDSMedicationDispenseObligations.md)
* [Medication prescription model](StructureDefinition-EHDSMedicationPrescription.md)
* [Medication prescription model obligations](StructureDefinition-EHDSMedicationPrescriptionObligations.md)
* [Medication use model](StructureDefinition-EHDSMedicationUse.md)
* [Observation model](StructureDefinition-EHDSObservation.md)
* [Organisation model](StructureDefinition-EHDSOrganisation.md)
* [Patient model](StructureDefinition-EHDSPatient.md)
* [Patient summary model](StructureDefinition-EHDSPatientSummary.md)
* [Pregnancy history model](StructureDefinition-EHDSPregnancyHistory.md)
* [Procedure model](StructureDefinition-EHDSProcedure.md)
* [Related person model](StructureDefinition-EHDSRelatedPerson.md)
* [Service request model](StructureDefinition-EHDSServiceRequest.md)
* [Specimen model](StructureDefinition-EHDSSpecimen.md)
* [Telecom model](StructureDefinition-EHDSTelecom.md)
* [Travel history model](StructureDefinition-EHDSTravelHistory.md)

### Logical Profiles

* [AllergyIntolerance obligations](StructureDefinition-EHDSAllergyIntoleranceObligations.md)
* [Dosage obligations](StructureDefinition-EHDSDosageObligations.md)
* [Immunisation obligations](StructureDefinition-EHDSImmunisationObligations.md)
* [MedicationAdministration obligations](StructureDefinition-EHDSMedicationAdministrationObligations.md)
* [Medication  model obligations](StructureDefinition-EHDSMedicationObligations.md)
* [MedicationUse obligations](StructureDefinition-EHDSMedicationUseObligations.md)
* [Observation obligations](StructureDefinition-EHDSObservationObligations.md)
* [Procedure obligations](StructureDefinition-EHDSProcedureObligations.md)

### ImplementationGuides

* [EHDS Logical Information Models](index.md)

### Examples

* [Consumer (ActorDefinition)](ActorDefinition-actor-consumer.md)
* [Producer (ActorDefinition)](ActorDefinition-actor-producer.md)
