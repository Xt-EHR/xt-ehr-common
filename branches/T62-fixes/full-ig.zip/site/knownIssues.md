# Known issues - EHDS Logical Information Models v0.2.0

* [**Table of Contents**](toc.md)
* **Known issues**

## Known issues

Reported findings and relevant discussions are documented as [GitHub issues](https://github.com/Xt-EHR/xt-ehr-common/issues).

